package com.example.shiyan1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.util.Log;
//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }
//}


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    private static final String TestApp="TestApp";

    //创建Button对象 也就是activity_main.xml里所设置的ID
    Button btn_0,btn_1,btn_2,btn_3,btn_4,btn_5,btn_6,btn_7,btn_8,btn_9,btn_pt;
    Button btn_mul,btn_div,btn_add,btn_sub;
    Button btn_clr,btn_del,btn_eq,btn_s,btn_c,btn_t,btn_f,btn_g;
    EditText et_input;  //可编辑的
    boolean clr_flag; //判断et编辑文本框中是否清空

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //实例化对象
        setContentView(R.layout.activity_main);
        btn_0= (Button) findViewById(R.id.btn_0);
        btn_1= (Button) findViewById(R.id.btn_1);
        btn_2= (Button) findViewById(R.id.btn_2);
        btn_3= (Button) findViewById(R.id.btn_3);
        btn_4= (Button) findViewById(R.id.btn_4);
        btn_5= (Button) findViewById(R.id.btn_5);
        btn_6= (Button) findViewById(R.id.btn_6);
        btn_7= (Button) findViewById(R.id.btn_7);
        btn_8= (Button) findViewById(R.id.btn_8);
        btn_9= (Button) findViewById(R.id.btn_9);
        btn_pt= (Button) findViewById(R.id.btn_pt);
        btn_add= (Button) findViewById(R.id.btn_add);
        btn_sub= (Button) findViewById(R.id.btn_sub);
        btn_mul= (Button) findViewById(R.id.btn_mul);
        btn_div= (Button) findViewById(R.id.btn_div);
        btn_clr= (Button) findViewById(R.id.btn_clr);
        btn_del= (Button) findViewById(R.id.btn_del);
        btn_eq= (Button) findViewById(R.id.btn_eq);
        btn_s= (Button) findViewById(R.id.btn_s);
        btn_c= (Button) findViewById(R.id.btn_c);
        btn_t= (Button) findViewById(R.id.btn_t);
        btn_g= (Button) findViewById(R.id.btn_g);
        btn_f= (Button) findViewById(R.id.btn_f);
        et_input= (EditText) findViewById(R.id.et_input);

        //给按钮设置的点击事件
        btn_0.setOnClickListener(this);
        btn_1.setOnClickListener(this);
        btn_2.setOnClickListener(this);
        btn_3.setOnClickListener(this);
        btn_4.setOnClickListener(this);
        btn_5.setOnClickListener(this);
        btn_6.setOnClickListener(this);
        btn_7.setOnClickListener(this);
        btn_8.setOnClickListener(this);
        btn_9.setOnClickListener(this);
        btn_pt.setOnClickListener(this);
        btn_add.setOnClickListener(this);
        btn_sub.setOnClickListener(this);
        btn_mul.setOnClickListener(this);
        btn_div.setOnClickListener(this);
        btn_clr.setOnClickListener(this);
        btn_del.setOnClickListener(this);
        btn_eq.setOnClickListener(this);
        btn_s.setOnClickListener(this);
        btn_c.setOnClickListener(this);
        btn_t.setOnClickListener(this);
        btn_f.setOnClickListener(this);
        btn_g.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String str=et_input.getText().toString();
        Log.v(TestApp,"str0="+str);
        switch (v.getId()){
            case R.id.btn_s:
            case R.id.btn_c:
            case R.id.btn_t:
            case R.id.btn_g:
                if(clr_flag){
                    clr_flag=false;
                    str="";
                    et_input.setText("");
                }
                et_input.setText(str+((Button)v).getText()+" ");
                break;
            case R.id.btn_f:
                //用于下一个算式的清屏
                if(clr_flag){
                    clr_flag=false;
                    str="";
                    et_input.setText("");
                }
                et_input.setText(str+((Button)v).getText());
                break;
            case R.id.btn_0:
            case R.id.btn_1:
            case R.id.btn_2:
            case R.id.btn_3:
            case R.id.btn_4:
            case R.id.btn_5:
            case R.id.btn_6:
            case R.id.btn_7:
            case R.id.btn_8:
            case R.id.btn_9:
            case R.id.btn_pt:
                if(clr_flag){
                    clr_flag=false;
                    str="";
                    et_input.setText("");
                }
                et_input.setText(str+((Button)v).getText());
                break;
            case R.id.btn_add:
            case R.id.btn_sub:
            case R.id.btn_mul:
            case R.id.btn_div:
                if(clr_flag){
                    clr_flag=false;
                    str="";
                    Log.v(TestApp,"str2="+str);
                    et_input.setText("");
                }
                if(str.contains("+")||str.contains("-")||str.contains("×")||str.contains("÷")) {
                    str=str.substring(0,str.indexOf(" "));
                }
                et_input.setText(str+" "+((Button)v).getText()+" ");
                break;
            case R.id.btn_clr:
                if(clr_flag)
                    clr_flag=false;
                str="";
                et_input.setText("");
                break;
            case R.id.btn_del: //判断是否为空，然后在进行删除
                if(clr_flag){
                    clr_flag=false;
                    Log.v(TestApp,"str3="+str);
                    str="";
                    et_input.setText("");
                }
                else if(str!=null&&!str.equals("")){
                    et_input.setText(str.substring(0,str.length()-1));
                }
                break;

            case R.id.btn_eq: //单独运算最后结果
                getResult();//调用下面的方法
                break;
        }
    }

    private void getResult() {
        String exp=et_input.getText().toString();
        if(exp==null||exp.equals("")) return ;
        //因为没有运算符所以不用运算
        if(!exp.contains(" ")){
            return ;
        }
        if(clr_flag){
            clr_flag=false;
            return;
        }
        clr_flag=true;
        double cnt=0;
        //截取运算符前面的字符串
        String s1=exp.substring(0,exp.indexOf(" "));   //传入
        if (s1.equals("sin")||s1.equals("cos")||s1.equals("tan")||s1.equals("gen")){
            if(s1.equals("sin")){
                //判断是否为负数
                String n=exp.substring(exp.indexOf(" ")+1,exp.indexOf(" ")+2);
                if (n.equals("-")) {
                    String num=exp.substring(exp.indexOf(" ")+2);
                    double s=Double.parseDouble(num);
                    s=s*(-1);
                    cnt=Math.sin(s*Math.PI/180);
                    et_input.setText(cnt+"");
                }
                else{
                    String num=exp.substring(exp.indexOf(" ")+1);
                    double s=Double.parseDouble(num);
                    cnt=Math.sin(s*Math.PI/180);
                    et_input.setText(cnt+"");
                }


            }
            if(s1.equals("cos")){
                String n=exp.substring(exp.indexOf(" ")+1,exp.indexOf(" ")+2);
                if (n.equals("-")) {
                    String num=exp.substring(exp.indexOf(" ")+2);
                    double s=Double.parseDouble(num);
                    s=s*(-1);
                    cnt=Math.cos(s*Math.PI/180);
                    et_input.setText(cnt+"");
                }
                else{
                    String num=exp.substring(exp.indexOf(" ")+1);
                    double s=Double.parseDouble(num);
                    cnt=Math.cos(s*Math.PI/180);
                    et_input.setText(cnt+"");
                }

            }
            if(s1.equals("tan")){
                String n=exp.substring(exp.indexOf(" ")+1,exp.indexOf(" ")+2);
                if (n.equals("-")) {
                    String num=exp.substring(exp.indexOf(" ")+2);
                    double s=Double.parseDouble(num);
                    s=s*(-1);
                    if((s%180)==-90.0){
                        et_input.setText("tan不能为90倍数") ;
                    }else{
                        cnt=Math.tan(s*Math.PI/180);
                        et_input.setText(cnt+"");}

                }
                else{
                    String num=exp.substring(exp.indexOf(" ")+1);
                    double s=Double.parseDouble(num);
                    if((s%180)==90.0){
                        et_input.setText("tan不能为90倍数") ;
                    }else{
                        cnt=Math.tan(s*Math.PI/180);
                        et_input.setText(cnt+"");}

                }

            }
            if(s1.equals("gen")){
                String n=exp.substring(exp.indexOf(" ")+1,exp.indexOf(" ")+2);
                if (n.equals("-")) {
                    et_input.setText("负数不能开更") ;
                }
                else{
                    String num=exp.substring(exp.indexOf(" ")+1);
                    double s=Double.parseDouble(num);
                    cnt=Math.sqrt(s);
                    et_input.setText(cnt+"");

                }

            }
        }
        else{
            //截取的运算符
            String op=exp.substring(exp.indexOf(" ")+1,exp.indexOf(" ")+2);
            //截取运算符后面的字符串
            String s2=exp.substring(exp.indexOf(" ")+3);


            if(!s1.equals("")&&!s2.equals("")){
                double d1,d2;   //传入
                //判断两个数是否为负数，并且将两个数变成相应的数
                String n=s1.substring(0,1);
                String m=s2.substring(0,1);
                if(n.equals("-")){
                    String s11=s1.substring(1);
                    s1=s11;
                    d1=Double.parseDouble(s1);
                    d1=d1*(-1.0);
                }
                else{
                    d1=Double.parseDouble(s1);
                }
                if(m.equals("-")){
                    String s12=s2.substring(1);
                    s2=s12;
                    d2=Double.parseDouble(s2);
                    d2=d2*(-1);
                }else{
                    d2=Double.parseDouble(s2);
                }
                if(op.equals("+")){
                    cnt=d1+d2;
                    //输出格式调整
                    if(!s1.contains(".")&&!s2.contains(".")) {
                        int res = (int) cnt;
                        et_input.setText(res+"");
                    }else {
                        et_input.setText(cnt+"");}
                }
                else if(op.equals("-")){
                    cnt=d1-d2;
                    if(!s1.contains(".")&&!s2.contains(".")) {
                        int res = (int) cnt;
                        et_input.setText(res+"");
                    }else {
                        et_input.setText(cnt+"");}
                }
                else if(op.equals("×")){
                    cnt=d1*d2;
                    if(!s1.contains(".")&&!s2.contains(".")) {
                        int res = (int) cnt;
                        et_input.setText(res+"");
                    }else {
                        et_input.setText(cnt+"");}
                }
                else if(op.equals("÷")){
                    if(d2==0) {
                        et_input.setText("除数不能为0");    //除数不能为空判断
                    }
                    else {
                        cnt=d1/d2;
                        et_input.setText(cnt+"");
                    }
                }
            }
            //如果s1不是空 s2是空 就执行下一步
            else if(!s1.equals("")&&s2.equals("")){
                double d1;
                //判断两个数是否为负数，并且将两个数变成相应的数
                String n=s1.substring(0,1);
                if(n.equals("_")){
                    String s11=s1.substring(1);
                    s1=s11;
                    d1=Double.parseDouble(s1);
                    d1=d1*(-1.0);
                }
                else {
                    d1 = Double.parseDouble(s1);
                }
                if(op.equals("+")){
                    cnt=d1;
                }
                if(op.equals("-")){
                    cnt=d1;
                }
                if(op.equals("×")){
                    cnt=0;
                }
                if(op.equals("÷")){
                    cnt=0;
                }
                if(!s1.contains(".")) {
                    int res = (int) cnt;
                    et_input.setText(res+"");
                }else {
                    et_input.setText(cnt+"");}
            }
            //如果s1是空 s2不是空 就执行下一步
            else if(s1.equals("")&&!s2.equals("")){
                double d2;
                //判断两个数是否为负数，并且将两个数变成相应的数
                String m=s2.substring(0,1);
                if(m.equals("_")){
                    String s12=s2.substring(1);
                    s2=s12;
                    d2=Double.parseDouble(s2);
                    d2=d2*(-1);
                }else{
                    d2=Double.parseDouble(s2);
                }
                if(op.equals("+")){
                    cnt=d2;
                }
                if(op.equals("-")){
                    cnt=0-d2;
                }
                if(op.equals("×")){
                    cnt=0;
                }
                if(op.equals("÷")){
                    cnt=0;
                }
                if(!s2.contains(".")) {
                    int res = (int) cnt;
                    et_input.setText(res+"");
                }else {
                    et_input.setText(cnt+"");}
            }
            else {
                et_input.setText("");
            }}

    }
}




